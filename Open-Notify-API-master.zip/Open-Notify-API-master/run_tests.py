#!/usr/bin/env python
import unittest
from testsuite.web import *
from testsuite.api import *

if __name__ == '__main__':
    unittest.main()
