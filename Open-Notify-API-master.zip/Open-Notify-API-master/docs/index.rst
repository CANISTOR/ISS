.. sidebar:: Contents

    .. toctree::
       :maxdepth: 2

       iss_location
       iss_pass


Open APIs From Space
====================

Open Notify is an open source project to provide a simple programming
interface for some of NASA’s awesome data. I do some of the work to take
raw data and turn them into APIs related to space and spacecraft.

APIs:
-----

 - :doc:`iss_location`
 - :doc:`iss_pass`
